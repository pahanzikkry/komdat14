<div class="mw-row">
  <div class="mw-col" style="width:50%" >
    <div class="mw-col-container">
        <div>
          <h2 class="element lipsum">Simple Text</h2>
          <p class="element lipsum"><?php print lipsum(); ?></p>
        </div>
    </div>
  </div>
  <div class="mw-col" style="width:50%" >
    <div class="mw-col-container" >
      <div>
          <h2 class="element lipsum">Simple Text</h2>
          <p class="element lipsum"><?php print lipsum(); ?></p>
      </div>
    </div>
  </div>
</div>
