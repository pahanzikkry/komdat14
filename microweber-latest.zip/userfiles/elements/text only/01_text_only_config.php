<?php
$config = array();
$config['name'] = "Simple Text";
$config['author'] = "Microweber";
$config['description'] = "Text 1 column full width";
$config['website'] = "http://microweber.com";
$config['categories'] = "simple, recommended";
$config['version'] = 0.41;
$config['position'] = 1;
$config['as_element'] = 1; 
 