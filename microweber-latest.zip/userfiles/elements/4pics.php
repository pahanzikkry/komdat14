
<div class="mw-row">
  <div class="mw-col" style="width:50%">
    <div class="mw-col-container">
        <img class="element img-polaroid" width="100%" src="<?php print pixum(400,150); ?>"  />
    </div>
  </div>
  <div class="mw-col" style="width:50%">
    <div class="mw-col-container">
        <img class="element img-polaroid" width="100%" src="<?php print pixum(400,150); ?>"  />
    </div>
  </div>
</div>
<div class="mw-row">
  <div class="mw-col" style="width:50%">
    <div class="mw-col-container">
        <img class="element img-polaroid" width="100%" src="<?php print pixum(400,150); ?>"  />
    </div>
  </div>
  <div class="mw-col" style="width:50%">
    <div class="mw-col-container">
        <img class="element img-polaroid" width="100%" src="<?php print pixum(400,150); ?>"  />
    </div>
  </div>
</div>
