<h3 class="element">LAST ARTICLES</h3>

<div class="mw-row ">
    <div class="mw-col" style="width: 33%">
      <div class="mw-col-container">
        <div class="element">
            <img class="element img-polaroid" width="100%"  src="<?php print pixum(280, 240); ?>" alt="" />
            <p class="element lipsum">July 11,  2012  Author Name</p>
            <h3 class="lipsum">Title</h3>
        </div>
      </div>
    </div>
    <div class="mw-col" style="width: 34%">
      <div class="mw-col-container">
        <div class="element">
            <img class="element img-polaroid" width="100%"  src="<?php print pixum(280, 240); ?>" alt="" />
            <p class="element lipsum">July 11,  2012  Author Name</p>
            <h3 class="lipsum">Title</h3>
        </div>
      </div>
    </div>
    <div class="mw-col" style="width: 33%">
      <div class="mw-col-container">
        <div class="element">
            <img class="element img-polaroid" width="100%"  src="<?php print pixum(280, 240); ?>" alt="" />
            <p class="element lipsum">July 11,  2012  Author Name</p>
            <h3 class="lipsum">Title</h3>
        </div>
      </div>
    </div>





</div>




