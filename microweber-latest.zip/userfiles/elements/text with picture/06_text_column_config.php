<?php

$config = array();
$config['name'] = "Text (3 columns) and wide picture";
$config['author'] = "Microweber";
$config['description'] = "Text (3 columns) and wide picture";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['as_element'] = true;

$config['categories'] = "portfolio";
$config['position'] = 9;
$config['version'] = 0.02;



