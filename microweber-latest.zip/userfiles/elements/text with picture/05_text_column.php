<img class="element img-polaroid" src="<?php print pixum(800, 150); ?>" width="100%" alt=""  />
<div class="mw-row">
  <div class="mw-col" style="width:50%" >
    <div class="mw-col-container" >
      <div class="element well">
          <h2 class="element lipsum">Two Columns & Picture</h2>
          <p class="element lipsum"><?php print lipsum(); ?></p>
      </div>
    </div>
  </div>
  <div class="mw-col" style="width:50%" >
    <div class="mw-col-container">
      <div class="element well">
          <h2 class="element lipsum">Two Columns & Picture</h2>
          <p class="element lipsum"><?php print lipsum(); ?></p>
      </div>
    </div>
  </div>
</div>
