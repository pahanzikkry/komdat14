<?php

$config = array();
$config['name'] = "Two Columns & Picture";
$config['author'] = "Microweber";
$config['description'] = "Text (2 columns) and wide picture";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
  $config['categories'] = "portfolio";
  $config['position'] = "8";
  $config['version'] = "0.2";
  $config['as_element'] = true;