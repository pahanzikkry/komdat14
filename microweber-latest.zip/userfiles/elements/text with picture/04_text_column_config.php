<?php

$config = array();
$config['name'] = "Text with Picture";
$config['author'] = "Microweber";
$config['description'] = "Text with wide picture on the top.";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
 $config['categories'] = "recommended";
 $config['position'] = "7";
 $config['version'] = "0.4";
 $config['as_element'] = true;
