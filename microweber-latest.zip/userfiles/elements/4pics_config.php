<?php

$config = array();
$config['name'] = "4 Pictures";
$config['author'] = "Microweber";
$config['description'] = "4 pictures in 2 columns";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "portfolio, online shop, gallery, recommended";
$config['version'] = 0.01;
$config['position'] = 10;
$config['as_element'] = true;
$config['layout_type'] = "dynamic";
