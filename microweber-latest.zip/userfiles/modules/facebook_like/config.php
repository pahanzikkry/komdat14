<?php

$config = array();
$config['name'] = "Facebook Like";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['categories'] = "social networks";
$config['version'] = 0.06;
$config['position'] =25;

