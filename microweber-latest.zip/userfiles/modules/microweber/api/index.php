<!DOCTYPE HTML>
<html>
    <head>
        <script type="text/javascript" src="<?php   print(site_url());  ?>apijs"></script>
        <script type="text/javascript" src="<?php   print(site_url());  ?>apijs_settings?id=<?php print CONTENT_ID; ?>"></script>
     </head>
    <body>
        {content}
    </body>
</html>