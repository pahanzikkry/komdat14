<module type="admin/panel/shop/customers" />
