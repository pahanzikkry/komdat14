<?php 
include($config['path_to_module'].'index.php');
 
  