<?php

$config = array();
$config['name'] = "Help";
$config['descti'] = "Help";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = false;
$config['ui_admin'] = false;
$config['categories'] = "help";
$config['position'] = 80;
$config['version'] = 0.2;


