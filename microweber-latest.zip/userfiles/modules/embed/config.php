<?php

$config = array();
$config['name'] = "Embed Code";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['categories'] = "other, content";
$config['position'] = 26;
$config['version'] = 0.5;


//defining the table fields
//$embed_table = array("embed_title"=> "text","embed_code"=> "text","created_at"=> "datetime");

//definig the table name as "embed_code"  
//$config['table'] = array('embed_code'=>$embed_table);