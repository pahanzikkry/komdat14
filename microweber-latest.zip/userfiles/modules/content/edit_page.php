
<?php
$is_quick=false;
if(isset($params["quick_edit"])){
    $is_quick=$params["quick_edit"];
}

include('quick.php');




?>
