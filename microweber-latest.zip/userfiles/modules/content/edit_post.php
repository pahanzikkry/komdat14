<?php 

$edit_post_mode = true;

include('edit.php');