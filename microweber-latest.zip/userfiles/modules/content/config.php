<?php

$config = array();
$config['name'] = "Content";
$config['description'] = "Shows dynamic content";

$config['author'] = "Microweber";
$config['ui'] = true;
$config['categories'] = "content";
$config['version'] = 0.1;
$config['position'] = 10;

